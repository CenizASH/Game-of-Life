#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LINE_SIZE 50

    int main() {
        FILE *file = fopen("stdin", "r");
        char arr[50][50];
        char line[LINE_SIZE];
        int i;
        int j;
        for(i=0; i<50; i++) {
            line[i] = '\0';
        }
        for(i=0; i<50; i++) {
            for(j=0; j<50; j++){
                arr[i][j] = '\0';
            }
        }
        if (stdin != NULL) {
            i=0;
            int lineSize = 0;
            fgets(line, sizeof line, stdin);
            while (line != NULL)
            {
                if( sizeof line == 0) {
                    printf("\n");
                }
                if((lineSize) >50) {
                    printf("\n");
                    lineSize = 0;
                }
                for(i=0; i<50; i++) {
                    if(line[i]=='\n') {
                        line[i]='\0';
                    }
                    if(line[i]=='\n' && line[i]=='\0') {
                        lineSize++;
                    }
                }
                printf("%s", line);
                printf(" ");
                //lineSize += sizeof line;
                fgets(line, sizeof line, stdin);
            }
            fclose(stdin);
        }
        else{
            printf("ERROR: OPENING FILE WAS UNSUCCESSFUL");
        }
        return 0;
    }